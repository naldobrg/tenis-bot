
import joblib
import numpy as np
import requests
import time
import os

TOKEN = os.getenv("TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
modelo = joblib.load("modelo_tenis.pkl")

def enviar_telegram(mensagem):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    requests.post(url, data={"chat_id": CHAT_ID, "text": mensagem})

def prever_partida():
    entrada = np.random.rand(1, 5)
    prob = modelo.predict_proba(entrada)[0][1]
    if prob > 0.6:
        enviar_telegram(f"⚡ Aposta sugerida: Jogador 1 com {prob:.2%} de chance!")

while True:
    prever_partida()
    time.sleep(3600)
